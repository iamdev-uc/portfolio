#!/bin/sh
set -eu
cd "$(dirname "$0")"
exec node server/server.cjs
