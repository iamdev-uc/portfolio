const {test}=require('node:test');
const assert=require('node:assert/strict');
const {spawn}=require('node:child_process');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const WebSocket=require('../server/vendor/ws');
const root=path.resolve(__dirname,'..');
function pause(ms){return new Promise(r=>setTimeout(r,ms));}
test('real server: clients share movement, economy, room password, capacity and durable session',async()=>{
 const tempRoot=path.join(root,'.test-data');fs.mkdirSync(tempRoot,{recursive:true});const data=fs.mkdtempSync(path.join(tempRoot,'server-'));const port=18000+Math.floor(Math.random()*6000);const peers=[];let processHandle;
 function start(){processHandle=spawn(process.execPath,['server/server.cjs'],{cwd:root,env:{...process.env,PORT:String(port),DATA_DIR:data},stdio:['ignore','pipe','pipe']});return new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(new Error('startup timeout')),5000);processHandle.stdout.on('data',b=>{if(b.toString().includes('VESPER listening')){clearTimeout(timer);resolve();}});processHandle.on('error',reject);processHandle.stderr.on('data',b=>{if(b.toString().includes('EADDRINUSE'))reject(new Error(b));});});}
 function stop(){return new Promise(resolve=>{if(processHandle.exitCode!==null)return resolve();processHandle.once('exit',resolve);processHandle.kill('SIGTERM');});}
 async function join(options={}){const socket=new WebSocket('ws://127.0.0.1:'+port+'/ws');const messages=[];peers.push(socket);socket.on('message',b=>messages.push(JSON.parse(b)));await new Promise((resolve,reject)=>{socket.once('open',resolve);socket.once('error',reject);});socket.send(JSON.stringify({type:'join',room:'friends',password:'orbit',name:'Пилот',...options}));const deadline=Date.now()+3000;while(Date.now()<deadline){const welcome=messages.find(x=>x.type==='welcome'||x.type==='error');if(welcome)return {socket,messages,welcome};await pause(20);}throw new Error('welcome timeout');}
 async function waitFor(client,predicate,ms=2500){const deadline=Date.now()+ms;while(Date.now()<deadline){const found=client.messages.find(predicate);if(found)return found;await pause(20);}throw new Error('snapshot timeout');}
 try{await start();assert.equal((await (await fetch('http://127.0.0.1:'+port+'/health')).json()).ok,true);const html=await fetch('http://127.0.0.1:'+port+'/');assert.equal(html.status,200);assert.ok((await html.text()).includes('VESPER'));assert.equal((await fetch('http://127.0.0.1:'+port+'/%2e%2e%2fserver/server.cjs')).status,403);
 const a=await join({name:'Альфа'}),b=await join({name:'Бета'});assert.equal(a.welcome.type,'welcome');assert.equal(b.welcome.type,'welcome');assert.notEqual(a.welcome.id,b.welcome.id);await waitFor(b,x=>x.type==='snapshot'&&Object.keys(x.world.players).length===2);
 const bad=await join({password:'wrong'});assert.equal(bad.welcome.type,'error');assert.match(bad.welcome.message,/пароль/);
 a.socket.send(JSON.stringify({type:'input',input:{thrust:-1,credits:999999,p:[999,999,999]}}));await waitFor(b,x=>x.type==='snapshot'&&x.world.players[a.welcome.id]?.p[2]>1101);const last=b.messages.filter(x=>x.type==='snapshot').at(-1);assert.equal(last.world.players[a.welcome.id].credits,650);
 b.socket.send(JSON.stringify({type:'action',action:{type:'land'}}));await waitFor(a,x=>x.type==='snapshot'&&x.world.players[b.welcome.id]?.landed==='aurora');b.socket.send(JSON.stringify({type:'action',action:{type:'buy',item:'shell'}}));const bought=await waitFor(a,x=>x.type==='snapshot'&&x.world.players[b.welcome.id]?.ammo.shell===150);assert.equal(bought.world.players[b.welcome.id].credits,690);
 for(let i=0;i<6;i++)assert.equal((await join({name:'Друг '+i})).welcome.type,'welcome');const full=await join();assert.equal(full.welcome.type,'error');assert.match(full.welcome.message,/8/);
 const token=b.welcome.token,id=b.welcome.id;b.socket.close();await pause(120);const reconnect=await join({token});assert.equal(reconnect.welcome.id,id);assert.equal(reconnect.welcome.world.players[id].ammo.shell,150);
 for(const s of peers)s.close();await pause(180);await stop();const file=JSON.parse(fs.readFileSync(path.join(data,'friends.json'),'utf8'));assert.equal(file.world.players[id].ammo.shell,150);assert.ok(!JSON.stringify(file).includes('"password":"orbit"'));await start();const restored=await join({token});assert.equal(restored.welcome.id,id);assert.equal(restored.welcome.world.players[id].credits,690);assert.equal(restored.welcome.world.players[id].ammo.shell,150);
 }finally{for(const s of peers)s.terminate();if(processHandle)await stop();fs.rmSync(data,{recursive:true,force:true});}
});
