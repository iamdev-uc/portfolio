'use strict';
const http=require('node:http');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const {WebSocketServer,WebSocket}=require('./vendor/ws');
const Core=require('../dist/core.js');
const ROOT=path.resolve(__dirname,'../dist');
const DATA=path.resolve(process.env.DATA_DIR||path.join(__dirname,'../data'));
const PORT=Number(process.env.PORT)||8080;
const MAX_ROOMS=Math.max(1,Math.min(100,Number(process.env.MAX_ROOMS)||12));
const MAX_PLAYERS=8;
const rooms=new Map();
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.txt':'text/plain; charset=utf-8','.ico':'image/x-icon','.svg':'image/svg+xml'};
fs.mkdirSync(DATA,{recursive:true});
function digest(password,salt){return crypto.scryptSync(password,salt,32).toString('hex');}
function safeEqual(a,b){const aa=Buffer.from(a),bb=Buffer.from(b);return aa.length===bb.length&&crypto.timingSafeEqual(aa,bb);}
function writeRoom(room){const state={version:1,name:room.name,salt:room.salt,passwordHash:room.passwordHash,world:Core.snapshot(room.world),sessions:Object.fromEntries(room.sessions)};const filename=path.join(DATA,room.name+'.json'),temp=filename+'.tmp';fs.writeFileSync(temp,JSON.stringify(state));fs.renameSync(temp,filename);}
function loadRoom(name){const filename=path.join(DATA,name+'.json');if(!fs.existsSync(filename))return null;try{const data=JSON.parse(fs.readFileSync(filename,'utf8'));if(data.version!==1||data.name!==name||typeof data.salt!=='string'||typeof data.passwordHash!=='string')throw new Error('bad room');return {name,salt:data.salt,passwordHash:data.passwordHash,world:Core.restoreWorld(data.world),sessions:new Map(Object.entries(data.sessions||{})),clients:new Map(),inputs:{},lastActive:Date.now()};}catch(e){console.error('Room could not be loaded:',name,e.message);throw new Error('Сохранение комнаты повреждено. Создай комнату с другим именем.');}}
function createRoom(name,password,pvp){const salt=crypto.randomBytes(16).toString('hex'),room={name,salt,passwordHash:digest(password,salt),world:Core.createWorld(),sessions:new Map(),clients:new Map(),inputs:{},lastActive:Date.now()};room.world.pvp=!!pvp;return room;}
function send(socket,message){if(socket.readyState===WebSocket.OPEN&&socket.bufferedAmount<1e6)socket.send(JSON.stringify(message));}
function reject(socket,message){send(socket,{type:'error',message});socket.close(1008,'Join rejected');}
const server=http.createServer((req,res)=>{
 if(req.method!=='GET'&&req.method!=='HEAD'){res.writeHead(405,{'Allow':'GET, HEAD'});return res.end();}
 let pathname;try{pathname=decodeURIComponent(new URL(req.url,'http://local').pathname);}catch{res.writeHead(400);return res.end();}
 if(pathname==='/health'){res.writeHead(200,{'Content-Type':'application/json'});return res.end(JSON.stringify({ok:true,version:'1.0.0',rooms:rooms.size,players:[...rooms.values()].reduce((s,r)=>s+r.clients.size,0)}));}
 if(pathname==='/')pathname='/index.html';
 const file=path.resolve(ROOT,'.'+pathname);if(!file.startsWith(ROOT+path.sep)||pathname.includes('\0')||pathname.split('/').some(s=>s.startsWith('.'))){res.writeHead(403);return res.end('Forbidden');}
 fs.stat(file,(err,stat)=>{if(err||!stat.isFile()){res.writeHead(404);return res.end('Not found');}res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream','Content-Length':stat.size,'Cache-Control':'no-cache','X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin'});if(req.method==='HEAD')return res.end();fs.createReadStream(file).on('error',()=>res.destroy()).pipe(res);});
});
const wss=new WebSocketServer({noServer:true,maxPayload:4096,perMessageDeflate:false});
server.on('upgrade',(req,socket,head)=>{let url;try{url=new URL(req.url,'http://local');}catch{socket.destroy();return;}if(url.pathname!=='/ws'){socket.end('HTTP/1.1 404 Not Found\r\n\r\n');return;}if(wss.clients.size>=MAX_ROOMS*MAX_PLAYERS+16){socket.end('HTTP/1.1 503 Service Unavailable\r\n\r\n');return;}wss.handleUpgrade(req,socket,head,ws=>wss.emit('connection',ws,req));});
function wireWorld(room){const world=Core.snapshot(room.world);world.players=Object.fromEntries([...room.clients.keys()].filter(id=>world.players[id]).map(id=>[id,world.players[id]]));return world;}
wss.on('connection',socket=>{
 socket.alive=true;socket.rate=0;socket.rateSince=Date.now();socket.actions=0;socket.actionsSince=Date.now();socket.joined=false;socket.joinAttempts=0;
 const joinTimeout=setTimeout(()=>{if(!socket.joined)socket.close(1008,'Join timeout');},8000);
 socket.on('pong',()=>socket.alive=true);
 socket.on('message',raw=>{
  const now=Date.now();if(now-socket.rateSince>1000){socket.rate=0;socket.rateSince=now;}if(++socket.rate>90)return socket.close(1008,'Rate limit');
  let msg;try{msg=JSON.parse(raw.toString());}catch{return socket.close(1007,'Invalid JSON');}if(!msg||typeof msg!=='object')return;
  if(!socket.joined){
   if(msg.type!=='join')return;if(++socket.joinAttempts>1)return socket.close(1008,'Duplicate join');
   const name=typeof msg.room==='string'?msg.room.toLowerCase():'',password=typeof msg.password==='string'?msg.password:'';
   if(!/^[a-z0-9_-]{1,24}$/.test(name)||password.length>64)return reject(socket,'Некорректная комната или слишком длинный пароль.');
   let room=rooms.get(name);try{if(!room){if(rooms.size>=MAX_ROOMS)return reject(socket,'На сервере достигнут лимит активных комнат.');room=loadRoom(name)||createRoom(name,password,msg.pvp);rooms.set(name,room);}}catch(e){return reject(socket,e.message);}
   if(!safeEqual(digest(password,room.salt),room.passwordHash))return reject(socket,'Неверный пароль комнаты.');
   let token=typeof msg.token==='string'&&/^[0-9a-f]{48}$/.test(msg.token)?msg.token:null;let session=token?room.sessions.get(token):null;let id=session?.id;
   if(id&&!room.world.players[id]){id=null;session=null;}
   if(room.clients.size>=MAX_PLAYERS&&!room.clients.has(id))return reject(socket,'Комната заполнена: максимум 8 пилотов.');
   if(id&&room.clients.has(id)){const old=room.clients.get(id);old.room=null;old.close(4001,'Reconnected in another tab');}
   if(!id){if(room.sessions.size>=64)return reject(socket,'Лимит сохранённых пилотов: создай новую комнату.');id='p-'+crypto.randomBytes(8).toString('hex');token=crypto.randomBytes(24).toString('hex');room.world.players[id]=Core.createPlayer(id,msg.name);room.world.players[id].p[0]+=room.clients.size*35;room.sessions.set(token,{id,created:Date.now()});}
   room.world.players[id].name=String(msg.name||'Странник').replace(/[\u0000-\u001f]/g,'').slice(0,20);room.world.players[id].invulnerable=8;
   socket.joined=true;socket.room=room;socket.playerId=id;socket.inputAt=now;room.clients.set(id,socket);room.lastActive=now;room.inputs[id]={};clearTimeout(joinTimeout);send(socket,{type:'welcome',id,token,world:wireWorld(room)});writeRoom(room);return;
  }
  const room=socket.room;if(!room)return;
  if(msg.type==='input'){room.inputs[socket.playerId]=Core.sanitizeInput(msg.input);socket.inputAt=now;}
  else if(msg.type==='action'){if(now-socket.actionsSince>1000){socket.actionsSince=now;socket.actions=0;}if(++socket.actions>12)return;if(msg.action&&typeof msg.action.type==='string')Core.action(room.world,socket.playerId,msg.action);}
 });
 socket.on('error',()=>{});
 socket.on('close',()=>{clearTimeout(joinTimeout);const room=socket.room;if(room&&room.clients.get(socket.playerId)===socket){room.clients.delete(socket.playerId);delete room.inputs[socket.playerId];const player=room.world.players[socket.playerId];if(player)player.v=[0,0,0];room.lastActive=Date.now();try{writeRoom(room);}catch(e){console.error('Save failed:',e.message);}}});
});
const timestep=1/30;let last=performance.now(),accumulator=0,broadcastTick=0;
const loop=setInterval(()=>{const now=performance.now();accumulator+=Math.min(.2,(now-last)/1000);last=now;while(accumulator>=timestep){for(const room of rooms.values()){
 if(!room.clients.size)continue;const offline={};for(const [id,player] of Object.entries(room.world.players))if(!room.clients.has(id)){offline[id]=player;delete room.world.players[id];}
 for(const [id,client] of room.clients)if(Date.now()-client.inputAt>600)room.inputs[id]={brake:true};
 Core.tick(room.world,room.inputs,timestep);Object.assign(room.world.players,offline);
 }accumulator-=timestep;broadcastTick++;if(broadcastTick%2===0)for(const room of rooms.values())if(room.clients.size){const message={type:'snapshot',world:wireWorld(room)};for(const socket of room.clients.values())send(socket,message);}}
},1000/60);
const saves=setInterval(()=>{for(const [name,room] of rooms){try{writeRoom(room);}catch(e){console.error('Save failed:',name,e.message);}if(!room.clients.size&&Date.now()-room.lastActive>5*60*1000)rooms.delete(name);}},10000);
const heartbeat=setInterval(()=>{for(const socket of wss.clients){if(!socket.alive){socket.terminate();continue;}socket.alive=false;socket.ping();}},15000);
function shutdown(){clearInterval(loop);clearInterval(saves);clearInterval(heartbeat);for(const room of rooms.values()){try{writeRoom(room);}catch(e){console.error(e.message);}}for(const socket of wss.clients)socket.close(1001,'Server shutdown');server.close(()=>process.exit(0));setTimeout(()=>process.exit(0),1500).unref();}
process.on('SIGTERM',shutdown);process.on('SIGINT',shutdown);
server.listen(PORT,'0.0.0.0',()=>console.log('VESPER listening on http://0.0.0.0:'+PORT+' · data: '+DATA));
