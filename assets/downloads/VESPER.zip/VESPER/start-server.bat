@echo off
cd /d "%~dp0"
node server\server.cjs
pause
